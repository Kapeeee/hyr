<?php

// Muestra toda la informacion, por omision INFO_ALL
phpinfo();

?>