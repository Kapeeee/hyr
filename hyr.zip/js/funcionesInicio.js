//INSTANCIAS DE DATATABLE

$(document).ready(function () {
    $('#doc_ven').DataTable({
      "language": {
        "url": "//cdn.datatables.net/plug-ins/1.10.15/i18n/Spanish.json"
      }
    });
    $('.dataTables_length').addClass('bs-select');
  });